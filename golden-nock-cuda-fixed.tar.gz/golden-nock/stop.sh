#!/usr/bin/env bash
# stop.sh - stop the golden-miner started by start.sh
set -euo pipefail

BASEDIR=$(cd "$(dirname "$0")/.." && pwd)
PIDFILE="$BASEDIR/miner.pid"

if [ -f "$PIDFILE" ]; then
  PID=$(cat "$PIDFILE" 2>/dev/null || echo "")
  if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
    kill -TERM "$PID" || true
    # wait up to 10s
    for i in {1..10}; do
      if kill -0 "$PID" 2>/dev/null; then sleep 1; else break; fi
    done
    if kill -0 "$PID" 2>/dev/null; then kill -KILL "$PID" || true; fi
  fi
  rm -f "$PIDFILE"
  echo "Miner stopped."
else
  echo "No PID file found: $PIDFILE"
fi
