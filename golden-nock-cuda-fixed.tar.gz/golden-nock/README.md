# Golden Nock Custom Miner for mmpOS (CUDA)

This is a custom integration package for mmpOS.
It wraps the GoldenMiner NockChain GPU miner.
