#!/usr/bin/env bash
# mmp-stats.sh — GoldenMiner NOCK GPU miner stats parser for mmpOS
# Compatible with BusyBox tools (grep/sed/awk)
# Usage: mmp-stats.sh <GPU_COUNT> <LOG_FILE>
set -euo pipefail

GPU_COUNT=${1:-0}
LOG_FILE=${2:-/var/log/mmp/miner.log}

# change to script dir
cd "$(dirname "$0")"

# Load metadata if present
if [ -f ./mmp-external.conf ]; then
  . ./mmp-external.conf
else
  EXTERNAL_NAME="golden-nock"
  EXTERNAL_VERSION="1.5"
fi

# helper: get pci bus ids
get_bus_ids() {
  local vendor="$1"
  if ! command -v lspci >/dev/null 2>&1; then
    echo ""
    return
  fi
  /bin/lspci -n 2>/dev/null | awk -v vid="$vendor" '$2 ~ /^0300|0302:/ && $3 ~ vid {print $1}'
}

build_busid_json() {
  local amd=( $(get_bus_ids "1002") )
  local nv=( $(get_bus_ids "10de") )
  local intel=( $(get_bus_ids "8086") )
  local arr=( "cpu" )
  for id in "${amd[@]}" "${nv[@]}" "${intel[@]}"; do
    if [ -n "$id" ]; then arr+=("$id"); fi
  done
  local json="["
  for id in "${arr[@]}"; do json+=""$id","; done
  json="${json%,}]"
  echo "$json"
}

declare -a hash_gpu
get_cards_hashes() {
  if [ ! -f "$LOG_FILE" ]; then
    for ((i=0;i<GPU_COUNT;i++)); do hash_gpu[$i]=0; done
    return
  fi
  for ((i=0;i<GPU_COUNT;i++)); do
    local v
    v=$(grep -E "Card-${i} speed:" "$LOG_FILE" 2>/dev/null | tail -n1 | sed -E 's/.*Card-[0-9]+ speed:[[:space:]]*([0-9]+(\.[0-9]+)?).*/\1/')
    [ -z "$v" ] && v="0"
    v=$(echo "$v" | tr ',' '.')
    if ! echo "$v" | grep -Eq '^[0-9]+(\.[0-9]+)?$'; then v="0"; fi
    hash_gpu[$i]="$v"
  done
}

get_pool_shares() {
  if [ ! -f "$LOG_FILE" ]; then
    echo "0 0"
    return
  fi
  local last
  last=$(grep -F "Pool Stats" "$LOG_FILE" 2>/dev/null | tail -n1 || true)
  if [ -z "$last" ]; then echo "0 0"; return; fi
  local ac
  local rj
  ac=$(echo "$last" | sed -E 's/.*\(([0-9]+) Accepted.*/\1/' || echo "0")
  rj=$(echo "$last" | sed -E 's/.*Accepted, ([0-9]+) Rejected.*/\1/' || echo "0")
  if ! echo "$ac" | grep -Eq '^[0-9]+$'; then ac=0; fi
  if ! echo "$rj" | grep -Eq '^[0-9]+$'; then rj=0; fi
  echo "$ac $rj"
}

get_total_sols() {
  local sum=0
  for ((i=0;i<GPU_COUNT;i++)); do
    v="${hash_gpu[$i]:-0}"
    sum=$(awk -v s="$sum" -v v="$v" 'BEGIN {printf "%.6f", s + v}')
  done
  awk -v s="$sum" 'BEGIN {printf "%.2f", s}'
}

# MAIN
get_cards_hashes
read accepted rejected <<< "$(get_pool_shares)"
total_sols=$(get_total_sols)
busid_json=$(build_busid_json)

hash_json="["
for ((i=0;i<GPU_COUNT;i++)); do
  val="${hash_gpu[$i]:-0}"
  hash_json+="${val},"
done
hash_json="${hash_json%,}]"

jq -n   --argjson hash "$hash_json"   --argjson busid "$busid_json"   --arg units "sol/s"   --arg ac "$accepted" --arg inv "0" --arg rj "$rejected"   --arg miner_name "${EXTERNAL_NAME:-golden-nock}"   --arg miner_version "${EXTERNAL_VERSION:-1.5}"   --arg total "$total_sols"   '{$busid, $hash, $units, air: [$ac, $inv, $rj], miner_name: $miner_name, miner_version: $miner_version, total_sols: $total}'
