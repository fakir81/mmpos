#!/usr/bin/env bash
# start.sh - wrapper to start golden-miner-pool-prover for mmpOS
set -euo pipefail

BASEDIR=$(cd "$(dirname "$0")/.." && pwd)
cd "$BASEDIR"

# load external conf if present
if [ -f ./mmp-external.conf ]; then
  . ./mmp-external.conf
fi

# binary location: prefer ./bin/<EXTERNAL_BIN> then ./golden-miner-pool-prover
BIN="./bin/${EXTERNAL_BIN:-golden-miner-pool-prover}"
if [ ! -x "$BIN" ]; then
  if [ -x "./${EXTERNAL_BIN:-golden-miner-pool-prover}" ]; then
    BIN="./${EXTERNAL_BIN:-golden-miner-pool-prover}"
  else
    echo "ERROR: miner binary not found or not executable: $BIN"
    exit 2
  fi
fi

LOG_DIR="/var/log/mmp"
LOG_FILE="$LOG_DIR/miner.log"
mkdir -p "$LOG_DIR"
touch "$LOG_FILE"
PIDFILE="$BASEDIR/miner.pid"

# Accept environment placeholders or use defaults
POOL="${POOL_URL:-${EXTERNAL_CMD_OPTS:-}}"
WALLET="${WALLET:-default_wallet}"
DEVICES="${DEVICES:-}"

# Build command (preserve EXTERNAL_CMD_OPTS if set)
CMD="$BIN $EXTERNAL_CMD_OPTS"
# Example common flags: --proxy, --name, --threads-per-card, etc.
# If user provided POOL_URL or WALLET, append appropriate options (non-invasive)
if [ -n "$POOL" ]; then
  CMD="$CMD --proxy=$POOL"
fi
if [ -n "$WALLET" ]; then
  CMD="$CMD --name=$WALLET"
fi
if [ -n "$DEVICES" ]; then
  export CUDA_VISIBLE_DEVICES="$DEVICES"
fi

echo "Starting golden-miner with: $CMD"
nohup bash -c "$CMD" >> "$LOG_FILE" 2>&1 &
echo $! > "$PIDFILE"

echo "Started pid $(cat $PIDFILE)"
